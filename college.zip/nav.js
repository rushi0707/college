
var navb=document.getElementById("link");

function showMenu()
{
    navb.style.right="0";
}

function hideMenu()
{
    navb.style.right="-200px";
}
